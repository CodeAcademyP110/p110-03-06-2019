﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P110_WinForm_demo
{
    public partial class Dashboard : Form
    {
        private readonly List<string> users;

        public Dashboard()
        {
            InitializeComponent();
            users = new List<string> {
                "Ilkin Sardarov",
                "Samir Dadash-zade",
                "Kamran Orucov",
                "Medine Eliyeva"
            };
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            foreach (var user in users)
            {
                cmbUsers.Items.Add(user);
            }
            cmbUsers.SelectedIndex = 1;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string newUsername = txtUsername.Text;

            //misses checking

            lbUsersList.Items.Add(newUsername);
            txtUsername.Text = "";
        }
    }
}
